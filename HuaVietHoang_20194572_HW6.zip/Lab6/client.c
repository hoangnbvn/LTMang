#include <stdio.h>
#include <stdlib.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <string.h>
#include <unistd.h>

#define BUFF_SIZE 1024

int main(int argc, char** argv){
	int client_sock;
    char* SERVER_ADDR; int SERVER_PORT;
	char buff[BUFF_SIZE]; 
	struct sockaddr_in server_addr; /* server's address information */
	int msg_len, bytes_sent, bytes_received;

    char* bye = "@bye";
    // Read IP address and Port number
    if(argc != 3) {
        printf("Input again.\n");
        exit(0);
    }
    SERVER_ADDR = argv[1];
    SERVER_PORT = atoi(argv[2]);

    //Step 1: Construct socket
	client_sock = socket(AF_INET,SOCK_STREAM,0);

	//Step 2: Specify server address
	server_addr.sin_family = AF_INET;
	server_addr.sin_port = htons(SERVER_PORT);
	server_addr.sin_addr.s_addr = inet_addr(SERVER_ADDR);
	
	//Step 3: Request to connect server
	if(connect(client_sock, (struct sockaddr*)&server_addr, sizeof(struct sockaddr)) < 0){
		printf("\nError!Can not connect to sever! Client exit imediately! ");
		return 0;
	}
		
	//Step 4: Communicate with server			
	
	//send message
    printf("Input user name: ");
    memset(buff,'\0',(strlen(buff)+1));
	fgets(buff, BUFF_SIZE, stdin);		
	msg_len = strlen(buff);
		
	bytes_sent = send(client_sock, buff, msg_len, 0);
	if(bytes_sent < 0)
		perror("\nError: ");
	
	//receive echo reply
	bytes_received = recv(client_sock, buff, BUFF_SIZE, 0);
	if (bytes_received < 0)
			perror("\nError: ");
	else if (bytes_received == 0)
			printf("Connection closed.\n");	
	buff[bytes_received] = '\0';
	if(strcmp(buff,"@cname")==0) {
        for(int i=0; i<3; i++) {
            printf("Input password: ");
            memset(buff,'\0',strlen(buff)+1); fflush(stdin);
            fgets(buff, BUFF_SIZE, stdin);
            buff[strlen(buff)-1] = '\0';
            bytes_sent = send(client_sock, buff, strlen(buff), 0);
            if(bytes_sent < 0)	perror("\nError: ");

        	bytes_received = recv(client_sock, buff, BUFF_SIZE, 0);
        	if (bytes_received < 0)
			perror("\nError: ");
	        else if (bytes_received == 0)
			printf("Connection closed.\n");
	        buff[bytes_received] = '\0';
            
            if(strcmp(buff,"@cpass")==0) {
                printf("Login successfully.\n");
                printf("Input 'bye' to logout.\n");
                while (1)
                {
                    memset(buff,'\0',strlen(buff)+1); fflush(stdin);
                    fgets(buff, BUFF_SIZE, stdin);
                    buff[strlen(buff)-1] = '\0';

                    if(strcmp(buff,"bye")==0){
                        bytes_sent = send(client_sock, bye, strlen(bye), 0);
                        if(bytes_sent < 0)	perror("\nError: ");

                        bytes_received = recv(client_sock, buff, BUFF_SIZE, 0);
                        if (bytes_received < 0)
                        perror("\nError: ");
                        else if (bytes_received == 0)
                        printf("Connection closed.\n");
                        buff[bytes_received] = '\0';

                        if(strcmp(buff,"@out")==0) printf("Logout.\n");
                        break;
                    }

                }
                
                break;
            }
            else if(strcmp(buff,"@nready")==0) {
                printf("Account is not active.\n");
                break;
            }
            else if(strcmp(buff,"@wpass")==0) {
                printf("Password is not correct.\n");
                continue;
            }
            else if(strcmp(buff,"@block")==0) {
                printf("Account is blocked.\n");
                break;
            }

        }

    }
    if(strcmp(buff,"@wname")==0){
        printf("Username is not correct.\n");
    }
	//Step 4: Close socket
	close(client_sock);
	return 0;
}
