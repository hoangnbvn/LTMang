#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <netdb.h>
#include <sys/wait.h>
#include <errno.h>
#include <arpa/inet.h>
#include "dllist.h"
#include "fields.h"

#define BACKLOG 20
#define BUFF_SIZE 1024

typedef struct {
  char *name;
  char *pass;
  int status;
} Account;

void Print(Dllist l)
{
    Dllist ptr; 
    FILE *f = fopen("account.txt","w+");
    dll_traverse(ptr,l) {
        Account *tmp = (Account*)jval_v(dll_val(ptr)); 
        fprintf(f,"%s %s %d\n",tmp->name,tmp->pass,tmp->status);
    }
    fclose(f);
}

/* Handler process signal*/
void sig_chld(int signo);

/*
* Receive and echo message to client
* [IN] sockfd: socket descriptor that connects to client 	
*/
void echo(int sockfd);

int main(int argc, char** argv){
	int sin_size;
    int PORT;
	int listen_sock, conn_sock; /* file descriptors */
	int bytes_sent, bytes_received;
	struct sockaddr_in server; /* server's address information */
	struct sockaddr_in client; /* client's address information */
	pid_t pid;
  
    //Read Port number
    if(argc != 2){
        printf("Input again.\n");
        exit(0);
    }
    PORT = atoi(argv[1]);

	if ((listen_sock=socket(AF_INET, SOCK_STREAM, 0)) == -1 ){  /* calls socket() */
		printf("socket() error\n");
		return 0;
	}
	
	bzero(&server, sizeof(server));
	server.sin_family = AF_INET;         
	server.sin_port = htons(PORT);
	server.sin_addr.s_addr = htonl(INADDR_ANY);  /* INADDR_ANY puts your IP address automatically */   

	if(bind(listen_sock, (struct sockaddr*)&server, sizeof(server))==-1){ 
		perror("\nError: ");
		return 0;
	}     

	if(listen(listen_sock, BACKLOG) == -1){  
		perror("\nError: ");
		return 0;
	}
	
	/* Establish a signal handler to catch SIGCHLD */
	signal(SIGCHLD, sig_chld);

	while(1){
		sin_size=sizeof(struct sockaddr_in);
		if ((conn_sock = accept(listen_sock, (struct sockaddr *)&client, &sin_size))==-1){
			if (errno == EINTR)
				continue;
			else{
				perror("\nError: ");			
				return 0;
			}
		}
		
		/* For each client, fork spawns a child, and the child handles the new client */
		pid = fork();
		
		/* fork() is called in child process */
		if(pid  == 0){
			close(listen_sock);
			printf("You got a connection from %s\n", inet_ntoa(client.sin_addr)); /* prints client's IP */
			echo(conn_sock);					
			exit(0);
		}
		
		/* The parent closes the connected socket since the child handles the new client */
		close(conn_sock);
	}
	close(listen_sock);
	return 0;
}

void sig_chld(int signo){
	pid_t pid;
	int stat;
	
	/* Wait the child process terminate */
	while((pid = waitpid(-1, &stat, WNOHANG))>0)
		printf("\nChild %d terminated\n",pid);
}

void echo(int sockfd) {
	char buff[BUFF_SIZE];
	int bytes_sent, bytes_received;
	

	char* wname = "@wname";
	char* cname = "@cname";
	char* wpass = "@wpass";
	char* cpass = "@cpass";
	char* block = "@block";
    char* nready = "@nready";
	char* out = "@out";

	IS is; Dllist l,ptr;
    Account *a; Account *tmp;
    
    is = new_inputstruct("account.txt");
    l = new_dllist();

 	// Read from account.txt and add to link-list   
    while (get_line(is) >= 0) {
        if (is->NF > 1) {
            a = malloc(sizeof(Account));
            a->name = (char*)malloc(sizeof(char)*20);
            strcpy(a->name, is->fields[0]);
            a->pass = (char*)malloc(sizeof(char)*20);
            strcpy(a->pass, is->fields[1]);
            a->status = atoi(is->fields[2]);
            dll_append(l,new_jval_v(a));
        }
    }

	int check = 0;
	bytes_received = recv(sockfd, buff, BUFF_SIZE, 0); //blocking
	if (bytes_received < 0)
		perror("\nError: ");
	else if (bytes_received == 0)
		printf("Connection closed.");
	buff[bytes_received-1] = '\0';
    //Check user-name and pass
	dll_traverse(ptr, l)
    {
	    tmp = (Account*)jval_v(dll_val(ptr));
        // if can find username
        if(strcmp(tmp->name,buff) == 0){
			check = 1;
			int wrong = 0;
            bytes_sent = send(sockfd, (char*)cname, strlen(cname), 0);
			if(bytes_sent < 0)
				perror("\nError: ");
			for(int i=0; i<3; i++)
			{
				bytes_received = recv(sockfd, buff, BUFF_SIZE, 0);
				if (bytes_received < 0) perror("\nError: ");
				else if (bytes_received == 0) printf("Connection closed.");
				buff[bytes_received] = '\0';
				if(strcmp(tmp->pass,buff)==0) {
					if(tmp->status == 0) {
						bytes_sent = send(sockfd, (char*)nready, strlen(nready), 0);
						break;
					}
					else {
						bytes_sent = send(sockfd, (char*)cpass, strlen(cpass), 0);

						bytes_received = recv(sockfd, buff, BUFF_SIZE, 0);
						if (bytes_received < 0) perror("\nError: ");
						else if (bytes_received == 0) printf("Connection closed.");
						buff[bytes_received] = '\0';

						if(strcmp(buff,"@bye")==0)
						{
							bytes_sent = send(sockfd, (char*)out, strlen(out), 0);
						}
						break;
					}
				}
				else {
					wrong++;
					if(wrong>=3) {
						tmp->status = 0;
						bytes_sent = send(sockfd, (char*)block, strlen(block), 0);
						break;
					}
					else {
						bytes_sent = send(sockfd, (char*)wpass, strlen(wpass), 0);
						continue;
					}
				}
			}			
        }
    }	
	if(check == 0) {
        bytes_sent = send(sockfd, (char*)wname, strlen(wname), 0);
    }
	Print(l);
	free(a); free_dllist(l);  
    jettison_inputstruct(is);
	close(sockfd);
}